export const API_URL = 'https://api.example.com';
export const APP_NAME = 'My Expo App'